@extends('layouts.admin_auth_app')

@section('title', 'Forgot Password')

@section('content')


<h1>Show</h1>



@endsection
